<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>
<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>VSCMS | Terms & Conditions</title>
        <!-- App css -->
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/style.css" rel="stylesheet" type="text/css" />
        <script src="../assets/js/modernizr.min.js"></script>
    </head>
            <div class="card">
                <div class="card-block">

                    <div class="account-box">

                        <div class="card-box p-5">
                            <h3 class="text-uppercase text-center pb-4">
                                <a href="index.html" class="text-success">
                                    <span>VSCMS | Terms & Conditions</span>
                                </a>
                            </h3>
                            <hr />
                          



<h5>Privacy information</h5>
Our Commitment To Privacy
<hr />
<p>Your privacy is important to us. To better protect your privacy we provide this Privacy Policy, 
    which explains our online information practices and the choices you can make about the way 
    your information is collected and used. To make this Privacy Policy easy to find, 
    we make it available throughout our site and where personally identifiable data may be requested.</p>
<p>The Information We Collect</p>
<p>This Privacy Policy applies to all information collected or submitted on our website.
    On some pages, you may be able to order products, make requests, and register to receive email updates.
    The types of personal information collected at these pages include: </p>

<p>Name</p>
<p>E-mail address</p>
<p>Phone number</p>
<p>Address</p>

                            

                        </div>
                   </div>
               </div>
           </div>
        
            <div class="m-t-40 text-center">
                <p class="account-copyright"><?php echo date('Y');?> © Vehicle Service Center Managment System</p>
            </div>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>