   <footer class="footer">
                    <?php echo date('Y');?> © Vehicle Service Center Managment System
                </footer>
